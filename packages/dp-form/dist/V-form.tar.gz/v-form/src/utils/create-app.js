import { createApp } from 'vue'
import App from '../App.vue'

export const vfApp = createApp(App)