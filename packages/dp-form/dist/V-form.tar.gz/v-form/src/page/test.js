export default {
  "widgetList": [
  ],
  "formConfig": {
      "modelName": "formData",
      "refName": "vForm",
      "rulesName": "rules",
      "labelWidth": 80,
      "labelPosition": "top",
      "size": "",
      "labelAlign": "label-left-align",
      "cssCode": "",
      "customClass": [],
      "functions": "",
      "layoutType": "PC",
      "jsonVersion": 3,
      "onFormCreated": "",
      "onFormMounted": "",
      "onFormDataChange": "",
      "onFormValidate": "",
      "saveRemoteOptions": "never",
      "labelFormUniqueName": true,
      "dataSources": []
  }
}