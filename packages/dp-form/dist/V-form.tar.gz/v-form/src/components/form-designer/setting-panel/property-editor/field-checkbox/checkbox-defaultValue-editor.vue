<template>
  <div style="display: none"></div>
</template>

<script>
  export default {
    name: "checkbox-defaultValue-editor",
    props: {
      designer: Object,
      selectedWidget: Object,
      optionModel: Object,
    },
  }
</script>

<style scoped>

</style>
